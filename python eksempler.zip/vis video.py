import cv2

# Open the video file
cap = cv2.VideoCapture('video.mp4')

# Check if the video was opened correctly
if not cap.isOpened():
    print("Error: Could not open video file.")
    exit()

while True:
    # Read a frame from the video
    ret, frame = cap.read()

    # If the frame was successfully read, display it
    if ret:
        cv2.imshow('Video', frame)

        # Wait for the user to press 'q' to exit the loop
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    else:
        break

# Release the video capture object and close the display window
cap.release()
cv2.destroyAllWindows()

