import pygame
import random

# Initialize Pygame
pygame.init()

# Game settings
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
PLAYER_WIDTH = 50
PLAYER_HEIGHT = 60
PLATFORM_WIDTH = 100
PLATFORM_HEIGHT = 20
GATE_WIDTH = 50
GATE_HEIGHT = 60
GRAVITY = 0.5
JUMP_STRENGTH = -10
DOUBLE_JUMP_STRENGTH = -8
PLAYER_SPEED = 5
MAX_JUMP_HEIGHT = 150  # Maximum jump height, platforms should be within this distance.

# Colors
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BROWN = (139, 69, 19)  # Brown color for the ground
BLACK = (0, 0, 0)

# Create screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Jump to the Gate!')

# Player class
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((PLAYER_WIDTH, PLAYER_HEIGHT))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        self.velocity_x = 0
        self.velocity_y = 0
        self.on_ground = False
        self.jumps = 0  # Track the number of jumps (1 for normal jump, 2 for double jump)

    def update(self, keys):
        # Player movement
        if keys[pygame.K_LEFT]:
            self.velocity_x = -PLAYER_SPEED
        elif keys[pygame.K_RIGHT]:
            self.velocity_x = PLAYER_SPEED
        else:
            self.velocity_x = 0

        # Jumping (Allow jumping from the ground and double jump)
        if self.on_ground:
            if keys[pygame.K_SPACE]:
                self.velocity_y = JUMP_STRENGTH
                self.jumps = 1  # Reset to 1 jump when on the ground
                self.on_ground = False
        elif self.jumps == 1 and keys[pygame.K_SPACE]:
            self.velocity_y = DOUBLE_JUMP_STRENGTH
            self.jumps = 2  # Lock double jump once used

        # Apply gravity
        self.velocity_y += GRAVITY

        # Move the player
        self.rect.x += self.velocity_x
        self.rect.y += self.velocity_y

        # Check boundaries
        if self.rect.left < 0:
            self.rect.left = 0
        elif self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH

        # Prevent falling through the ground
        if self.rect.bottom > SCREEN_HEIGHT - PLATFORM_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT - PLATFORM_HEIGHT
            self.velocity_y = 0
            self.on_ground = True
            self.jumps = 0  # Reset jumps when back on the ground

    def check_collision(self, platforms):
        self.on_ground = False
        for platform in platforms:
            if self.rect.colliderect(platform.rect):
                if self.velocity_y > 0:  # Falling down
                    self.rect.bottom = platform.rect.top
                    self.velocity_y = 0
                    self.on_ground = True
                    self.jumps = 0  # Reset jumps when landing on a platform
                elif self.velocity_y < 0:  # Moving upwards (through platforms)
                    self.rect.top = platform.rect.bottom
                    self.velocity_y = 0  # Stop upward movement

# Platform class
class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
        self.image.fill(GREEN)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

# Gate class
class Gate(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((GATE_WIDTH, GATE_HEIGHT))
        self.image.fill(BLUE)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

# Game function
def game_loop():
    running = True
    clock = pygame.time.Clock()

    # Create sprite groups
    all_sprites = pygame.sprite.Group()
    platforms = pygame.sprite.Group()

    # Create player
    player = Player()
    all_sprites.add(player)

    # Create platforms (auto-generate)
    platform_y = SCREEN_HEIGHT - 100  # Start platforms above the ground

    # The first platform will be placed just above the ground
    platform = Platform(random.randint(50, SCREEN_WIDTH - 150), platform_y)
    platforms.add(platform)
    all_sprites.add(platform)

    previous_platform = platform
    platform_count = 0

    # Generate a path of platforms leading to the gate
    while platform_count < 10:  # Generate 10 platforms
        # Generate a platform within the jumpable range from the previous platform
        max_platform_distance = MAX_JUMP_HEIGHT
        new_platform_y = previous_platform.rect.y - random.randint(50, max_platform_distance)

        # Ensure platforms do not overlap
        new_platform_x = random.randint(50, SCREEN_WIDTH - PLATFORM_WIDTH - 50)
        platform = Platform(new_platform_x, new_platform_y)

        # Check if the new platform overlaps with existing platforms
        if all(p.rect.colliderect(platform.rect) == False for p in platforms):
            platforms.add(platform)
            all_sprites.add(platform)
            previous_platform = platform
            platform_count += 1

    # Create the gate at the highest platform
    gate = Gate(previous_platform.rect.centerx - (GATE_WIDTH // 2), previous_platform.rect.top - GATE_HEIGHT)
    all_sprites.add(gate)

    while running:
        screen.fill(WHITE)

        # Draw the ground (brown color)
        pygame.draw.rect(screen, BROWN, pygame.Rect(0, SCREEN_HEIGHT - PLATFORM_HEIGHT, SCREEN_WIDTH, PLATFORM_HEIGHT))

        # Check for quit events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Get key states
        keys = pygame.key.get_pressed()

        # Update game logic
        player.update(keys)
        player.check_collision(platforms)

        # Check for gate collision
        if player.rect.colliderect(gate.rect):
            print("You reached the gate! You win!")
            running = False

        # Draw everything
        all_sprites.draw(screen)

        pygame.display.flip()

        # Cap the frame rate
        clock.tick(60)

# Run the game
game_loop()

# Quit Pygame
pygame.quit()
