matplotlib
moviepy
opencv-python
PyOpenGL
numpy

