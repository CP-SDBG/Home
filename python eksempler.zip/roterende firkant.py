import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

# Define the vertices and edges of a cube
vertices = (
    (1, -1, -1),
    (1, 1, -1),
    (-1, 1, -1),
    (-1, -1, -1),
    (1, -1, 1),
    (1, 1, 1),
    (-1, 1, 1),
    (-1, -1, 1),
)

edges = (
    (0, 1),
    (1, 2),
    (2, 3),
    (3, 0),
    (4, 5),
    (5, 6),
    (6, 7),
    (7, 4),
    (0, 4),
    (1, 5),
    (2, 6),
    (3, 7),
)

# Function to draw the cube
def draw_cube():
    glBegin(GL_LINES)
    for edge in edges:
        for vertex in edge:
            glVertex3fv(vertices[vertex])
    glEnd()

# Function to initialize OpenGL settings
def initialize():
    glClearColor(0.0, 0.0, 0.0, 1.0)  # Set background color to black
    glEnable(GL_DEPTH_TEST)  # Enable depth testing for 3D effects

# Function to rotate and render the cube
def main():
    pygame.init()
    display = (800, 600)
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
    gluPerspective(45, (display[0] / display[1]), 0.1, 50.0)  # Set perspective
    glTranslatef(0.0, 0.0, -5)  # Move the cube back along the z-axis

    initialize()

    last_x, last_y = pygame.mouse.get_pos()  # Initial mouse position
    rotation_x, rotation_y = 0, 0  # Initial rotation angles

    rotation_x_direction, rotation_y_direction = 0, 0  # Directions of rotation
    is_mouse_in_window = True  # Flag to check if mouse is in window

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        # Get the current mouse position and check if the mouse is inside the window
        x, y = pygame.mouse.get_pos()
        is_mouse_in_window = pygame.mouse.get_focused()  # Check if mouse is inside the window

        # If the mouse is inside the window, track movement and update the rotation
        if is_mouse_in_window:
            delta_x = x - last_x
            delta_y = y - last_y

            # Update the rotation based on the mouse movement
            rotation_x += delta_y * 0.2
            rotation_y += delta_x * 0.2

            # Store the direction of the mouse movement for when the mouse is outside the window
            rotation_x_direction = delta_y
            rotation_y_direction = delta_x

            # Update the last mouse position
            last_x, last_y = x, y
        else:
            # Continue rotating in the last direction if the mouse is outside the window
            rotation_x += rotation_x_direction * 0.2
            rotation_y += rotation_y_direction * 0.2

        # Clear the screen
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        # Rotate the cube according to mouse movement or direction
        glPushMatrix()  # Save the current matrix state
        glRotatef(rotation_x, 1, 0, 0)  # Rotate around the x-axis
        glRotatef(rotation_y, 0, 1, 0)  # Rotate around the y-axis

        draw_cube()  # Draw the cube

        glPopMatrix()  # Restore the previous matrix state

        pygame.display.flip()  # Update the display

        pygame.time.wait(10)  # Control the speed of the rotation

if __name__ == "__main__":
    main()
