import cv2
from matplotlib import pyplot as plt

# Function to display the image in different modes
def display_image(choice, img, img_gray):
    if choice == 1:
        # Show the original image (RGB)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        plt.imshow(img_rgb)
        plt.title("Original Image")
    elif choice == 2:
        # Show the grayscale (monochrome) image
        plt.imshow(img_gray, cmap='gray')
        plt.title("Grayscale Image")
    elif choice == 3:
        # Show the blurred image
        img_blur = cv2.GaussianBlur(img, (15, 15), 0)
        img_rgb_blur = cv2.cvtColor(img_blur, cv2.COLOR_BGR2RGB)
        plt.imshow(img_rgb_blur)
        plt.title("Blurred Image")
    elif choice == 4:
        # Show the edges of the image using Canny
        edges = cv2.Canny(img_gray, 100, 200)
        plt.imshow(edges, cmap='gray')
        plt.title("Edge Detection (Canny)")
    elif choice == 5:
        # Apply edges on top of the original image
        edges = cv2.Canny(img_gray, 100, 200)
        img_edges_overlay = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img_edges_overlay[edges != 0] = [255, 0, 0]  # Red color for edges
        plt.imshow(img_edges_overlay)
        plt.title("Edges Overlay on Image")
    elif choice == 6:
        # Show the image with increased contrast
        img_contrast = cv2.convertScaleAbs(img, alpha=2.0, beta=0)
        img_rgb_contrast = cv2.cvtColor(img_contrast, cv2.COLOR_BGR2RGB)
        plt.imshow(img_rgb_contrast)
        plt.title("High Contrast Image")
    elif choice == 7:
        # Show the image with rotation (45 degrees)
        height, width = img.shape[:2]
        center = (width // 2, height // 2)
        rotation_matrix = cv2.getRotationMatrix2D(center, 45, 1.0)
        img_rotated = cv2.warpAffine(img, rotation_matrix, (width, height))
        img_rgb_rotated = cv2.cvtColor(img_rotated, cv2.COLOR_BGR2RGB)
        plt.imshow(img_rgb_rotated)
        plt.title("Rotated Image")

    elif choice == 8:
        # Display all images side by side
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img_blur = cv2.GaussianBlur(img, (15, 15), 0)
        img_blur_rgb = cv2.cvtColor(img_blur, cv2.COLOR_BGR2RGB)

        edges = cv2.Canny(img_gray, 100, 200)
        img_edges_overlay = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img_edges_overlay[edges != 0] = [255, 0, 0]

        img_contrast = cv2.convertScaleAbs(img, alpha=2.0, beta=0)
        img_contrast_rgb = cv2.cvtColor(img_contrast, cv2.COLOR_BGR2RGB)

        # Resize all images to the same size for side-by-side display
        height, width = img.shape[:2]
        new_width = 300
        aspect_ratio = width / float(height)
        new_height = int(new_width / aspect_ratio)

        img_rgb_resized = cv2.resize(img_rgb, (new_width, new_height))
        img_blur_resized = cv2.resize(img_blur_rgb, (new_width, new_height))
        img_edges_resized = cv2.resize(img_edges_overlay, (new_width, new_height))
        img_contrast_resized = cv2.resize(img_contrast_rgb, (new_width, new_height))

        # Stack images side by side
        all_images = cv2.hconcat([img_rgb_resized, img_blur_resized, img_edges_resized, img_contrast_resized])

        # Display the stacked images
        plt.imshow(all_images)
        plt.title("All Images Side by Side")
        plt.axis('off')
        plt.show()
        return True

    elif choice == 9:
        print("Exiting...")
        return False

    else:
        print("Invalid choice!")

    plt.show()
    return True

# Opening image
img = cv2.imread("image.jpg")

# OpenCV opens images as BRG, convert to grayscale
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Main loop for displaying the menu and handling choices
while True:
    # Show menu options
    print("\nSelect how you want to display the image:")
    print("1. Original Image (RGB)")
    print("2. Grayscale Image")
    print("3. Blurred Image")
    print("4. Edge Detection (Canny)")
    print("5. Edges Overlay on Image")
    print("6. High Contrast Image")
    print("7. Rotated Image (45 degrees)")
    print("8. Display Images Side by Side")
    print("9. Exit")


    # Take input from the user
    try:
        choice = int(input("Enter your choice (1-9): "))
    except ValueError:
        print("Invalid input. Please enter a number between 1 and 9.")
        continue

    if not display_image(choice, img, img_gray):
        break
