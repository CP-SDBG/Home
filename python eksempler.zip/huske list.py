import os
import random

class Task:
    def __init__(self, title, description, urgency):
        self.title = title
        self.description = description
        self.urgency = urgency

    def __repr__(self):
        return f"Task(title='{self.title}', description='{self.description}', urgency={self.urgency})"

    def to_file_format(self):
        """Convert task to a format that can be written to a file."""
        return f"{self.title},{self.description},{self.urgency}"

class TaskManager:
    def __init__(self):
        self.tasks = []

    def clear_screen(self):
        """Clear the terminal screen."""
        os.system('cls' if os.name == 'nt' else 'clear')

    def create_task(self):
        """Create a new task."""
        title = input("Enter the title of the task: ")
        description = input("Enter the description of the task: ")
        urgency = int(input("Enter the urgency of the task (1-10): "))
        new_task = Task(title, description, urgency)
        self.tasks.append(new_task)
        print(f"Task '{title}' created successfully.")

    def delete_task(self):
        """Delete an existing task."""
        self.show_tasks()
        task_index = int(input("Enter the task number to delete: ")) - 1
        if 0 <= task_index < len(self.tasks):
            deleted_task = self.tasks.pop(task_index)
            print(f"Task '{deleted_task.title}' deleted successfully.")
        else:
            print("Invalid task number.")

    def edit_task(self):
        """Edit an existing task."""
        self.show_tasks()
        task_index = int(input("Enter the task number to edit: ")) - 1
        if 0 <= task_index < len(self.tasks):
            task = self.tasks[task_index]
            print(f"Editing Task: {task.title}")
            title = input(f"Enter new title (current: {task.title}): ") or task.title
            description = input(f"Enter new description (current: {task.description}): ") or task.description
            urgency = input(f"Enter new urgency (current: {task.urgency}): ") or task.urgency
            urgency = int(urgency) if urgency else task.urgency

            # Apply the updates
            task.title = title
            task.description = description
            task.urgency = urgency

            print(f"Task '{task.title}' updated successfully.")
        else:
            print("Invalid task number.")

    def show_tasks(self):
        """Show the list of tasks in descending order of urgency."""
        sorted_tasks = sorted(self.tasks, key=lambda x: x.urgency, reverse=True)
        if not sorted_tasks:
            print("No tasks available.")
        else:
            print("\nTask List (Sorted by Urgency - Descending):")
            for i, task in enumerate(sorted_tasks, 1):
                print(f"{i}. {task.title} (Urgency: {task.urgency}) - {task.description}")

    def save_to_file(self):
        """Save the task list to a file."""
        with open("myTaskList.txt", "w") as file:
            for task in self.tasks:
                file.write(task.to_file_format() + "\n")
        print("Task list saved to 'myTaskList.txt'.")

    def load_from_file(self):
        """Load the task list from a saved file."""
        if os.path.exists("myTaskList.txt"):
            self.tasks.clear()
            with open("myTaskList.txt", "r") as file:
                for line in file:
                    title, description, urgency = line.strip().split(',')
                    self.tasks.append(Task(title, description, int(urgency)))
            print("Task list loaded from 'myTaskList.txt'.")
        else:
            print("No saved task list found.")

    def add_default_tasks(self):
        """Add default tasks with random urgency."""
        print("\nAdding default tasks...")
        for i in range(10):
            title = f"Task {i+1}"
            description = f"Description for task {i+1}"
            urgency = random.randint(1, 10)
            self.tasks.append(Task(title, description, urgency))
        print("Default tasks added successfully.")

    def clear_task_list(self):
        """Clear the current task list."""
        self.tasks.clear()
        print("Current task list cleared.")

    def quit_program(self):
        """Quit the program."""
        print("Exiting the task manager. Goodbye!")
        exit()

    def show_menu(self):
        """Display the main menu."""
        self.clear_screen()
        print("Task Manager")
        print("1. Create a task")
        print("2. Delete a task")
        print("3. Edit a task")
        print("4. Show task list")
        print("5. Save task list to file")
        print("6. Load task list from file")
        print("7. Add default tasks")
        print("8. Clear current task list")
        print("9. Quit")

    def run(self):
        """Run the main program loop."""
        while True:
            self.show_menu()
            choice = input("Enter your choice: ")

            if choice == '1':
                self.clear_screen()
                self.create_task()
            elif choice == '2':
                self.clear_screen()
                self.delete_task()
            elif choice == '3':
                self.clear_screen()
                self.edit_task()
            elif choice == '4':
                self.clear_screen()
                self.show_tasks()
            elif choice == '5':
                self.clear_screen()
                self.save_to_file()
            elif choice == '6':
                self.clear_screen()
                self.load_from_file()
            elif choice == '7':
                self.clear_screen()
                self.add_default_tasks()
            elif choice == '8':
                self.clear_screen()
                self.clear_task_list()
            elif choice == '9':
                self.quit_program()
            else:
                print("Invalid choice. Please try again.")

if __name__ == "__main__":
    task_manager = TaskManager()
    task_manager.run()
