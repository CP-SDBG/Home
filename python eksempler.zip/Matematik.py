import numpy as np
import matplotlib.pyplot as plt

def find_intersection(m1, b1, m2, b2):
    # Solves m1*x + b1 = m2*x + b2 for x
    if m1 == m2:
        raise ValueError("The lines are parallel and do not intersect.")
    x = (b2 - b1) / (m1 - m2)
    y = m1 * x + b1
    return x, y

def find_circle_line_intersection(circle_center, radius, m, b):
    # Solves the intersection of a circle and a line
    h, k = circle_center
    A = 1 + m**2
    B = 2 * (m * b - m * k - h)
    C = h**2 + k**2 + b**2 - 2 * b * k - radius**2

    discriminant = B**2 - 4 * A * C

    if discriminant < 0:
        raise ValueError("The line does not intersect the circle.")

    x1 = (-B + np.sqrt(discriminant)) / (2 * A)
    x2 = (-B - np.sqrt(discriminant)) / (2 * A)
    y1 = m * x1 + b
    y2 = m * x2 + b

    return (x1, y1), (x2, y2)

def tangent_line_to_circle(circle_center, radius, point):
    # Finds the tangent line equation at a point on the circle
    h, k = circle_center
    x1, y1 = point
    if abs(np.sqrt((x1 - h)**2 + (y1 - k)**2) - radius) > 1e-6:
        raise ValueError("The point is not on the circle.")

    # Slope of the tangent line
    if x1 != h:
        m_tangent = -(x1 - h) / (y1 - k)
    else:
        m_tangent = 0  # Vertical tangent line

    # Intercept of the tangent line
    b_tangent = y1 - m_tangent * x1

    return m_tangent, b_tangent

def plot_graphs():
    # Default equations for lines
    m1, b1 = 2, 3  # First line: y = 2x + 3
    m2, b2 = -1, 1  # Second line: y = -x + 1

    # Circle properties
    circle_center = (0, 0)  # Center of the circle
    radius = 5  # Radius of the circle

    # Find intersection point of two lines
    try:
        x_intersect, y_intersect = find_intersection(m1, b1, m2, b2)
    except ValueError as e:
        print(e)
        return

    # Find a point of tangency on the circle (use a specific point for simplicity)
    tangent_point = (radius / np.sqrt(2), radius / np.sqrt(2))  # 45-degree point on the circle
    try:
        m_tangent, b_tangent = tangent_line_to_circle(circle_center, radius, tangent_point)
    except ValueError as e:
        print(e)
        return

    # Generate x values for plotting
    x_values = np.linspace(-10, 10, 400)

    # Generate y values for both equations
    y_values_line1 = m1 * x_values + b1
    y_values_line2 = m2 * x_values + b2

    # Generate y values for the tangent line
    y_values_tangent = m_tangent * x_values + b_tangent

    # Circle data
    theta = np.linspace(0, 2 * np.pi, 400)
    circle_x = circle_center[0] + radius * np.cos(theta)
    circle_y = circle_center[1] + radius * np.sin(theta)

    # Plot everything
    plt.figure(figsize=(8, 8))

    # Plot the lines
    plt.plot(x_values, y_values_line1, label=f'y = {m1}x + {b1}', color='blue')
    plt.plot(x_values, y_values_line2, label=f'y = {m2}x + {b2}', color='green')

    # Plot the circle
    plt.plot(circle_x, circle_y, label=f'Circle (center={circle_center}, radius={radius})', color='purple')

    # Plot the tangent line
    plt.plot(x_values, y_values_tangent, label=f'Tangent Line (y = {m_tangent:.2f}x + {b_tangent:.2f})', color='orange')

    # Mark the intersection point of the two lines
    plt.scatter(x_intersect, y_intersect, color='red', zorder=5, label=f'Line Intersection ({x_intersect:.2f}, {y_intersect:.2f})')

    # Mark the tangent point
    plt.scatter(*tangent_point, color='brown', zorder=5, label=f'Tangent Point ({tangent_point[0]:.2f}, {tangent_point[1]:.2f})')

    # Add labels, legend, and grid
    plt.title('Lines, Circle, and Tangent Line')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.axhline(0, color='black', linewidth=0.5)
    plt.axvline(0, color='black', linewidth=0.5)
    plt.grid(color='gray', linestyle='--', linewidth=0.5)
    plt.legend()

    # Show the plot
    plt.show()

if __name__ == "__main__":
    plot_graphs()
